package uz.insof.click_tracker_service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ClickTrackerServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ClickTrackerServiceApplication.class, args);
	}

}
