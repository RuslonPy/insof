package uz.insof.generator_service;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GeneratorServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
